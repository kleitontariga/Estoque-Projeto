package br.com.estoque.estoque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
